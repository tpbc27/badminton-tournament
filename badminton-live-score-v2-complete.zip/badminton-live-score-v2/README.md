# 🏸 Badminton Live Score V2

Versi dipertingkat untuk pengurusan kejohanan badminton.

## Yang telah disediakan
- Bahasa Melayu sepenuhnya.
- Dashboard.
- Admin & Pengadil.
- Cipta kejohanan.
- Kategori perseorangan dan beregu.
- Tambah/padam pemain atau pasangan.
- Seed.
- Bracket kalah mati automatik.
- Bye automatik.
- Live score.
- Skor Set 1/2/3.
- Mata semasa.
- Sahkan perlawanan.
- Pemenang bergerak ke pusingan seterusnya.
- Undo perubahan skor.
- Jadual lengkap.
- Pengurusan akaun pengadil.
- Realtime sync dengan Socket.IO.
- SQLite dengan foreign keys dan WAL.
- Responsive untuk telefon, tablet dan desktop.

## Jalankan di komputer

Perlu Node.js 20+.

```bash
npm install
npm start
```

Buka:
`http://localhost:3000`

Akaun admin lalai:
- Username: `admin`
- Password: `admin123`

**Tukar segera password untuk penggunaan sebenar.**

## Deployment

Set environment:
- `JWT_SECRET`
- `ADMIN_USERNAME`
- `ADMIN_PASSWORD`

Start command:
`npm start`

Untuk hosting yang menggunakan filesystem sementara, SQLite tidak sesuai untuk data pertandingan jangka panjang. Gunakan persistent disk atau tukar database kepada PostgreSQL/Supabase.

## Aliran penggunaan

1. Admin log masuk.
2. Cipta kejohanan.
3. Pilih kategori/disiplin.
4. Tambah semua pemain/pasangan.
5. Jana Carta Pertandingan.
6. Beri akaun kepada pengadil.
7. Pengadil log masuk melalui URL yang sama.
8. Pengadil buka Live Score dan kemas kini skor.
9. Sahkan perlawanan.
10. Sistem memindahkan pemenang ke pusingan seterusnya.

## Nota
Versi ini menggunakan format kalah mati dan Best of 3. Peraturan teknikal seperti 21 mata, deuce, interval, service law dan walkover boleh dikembangkan dalam modul peraturan jika diperlukan oleh kejohanan.
