const express = require("express");
const http = require("http");
const path = require("path");
const fs = require("fs");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const Database = require("better-sqlite3");
const { Server } = require("socket.io");

const app = express();
const server = http.createServer(app);
const io = new Server(server);
const PORT = Number(process.env.PORT || 3000);
const SECRET = process.env.JWT_SECRET || "CHANGE_ME_IN_PRODUCTION";

fs.mkdirSync(path.join(__dirname, "data"), {recursive:true});
const db = new Database(path.join(__dirname, "data", "badminton.db"));
db.pragma("journal_mode=WAL");
db.pragma("foreign_keys=ON");

db.exec(`
CREATE TABLE IF NOT EXISTS users(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 username TEXT UNIQUE NOT NULL,
 password_hash TEXT NOT NULL,
 role TEXT NOT NULL CHECK(role IN ('admin','referee'))
);
CREATE TABLE IF NOT EXISTS tournaments(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 name TEXT NOT NULL,
 date TEXT DEFAULT '',
 venue TEXT DEFAULT '',
 category TEXT NOT NULL,
 discipline TEXT NOT NULL DEFAULT 'Perseorangan Lelaki',
 format TEXT NOT NULL DEFAULT 'knockout',
 best_of INTEGER NOT NULL DEFAULT 3,
 status TEXT NOT NULL DEFAULT 'Draf',
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS players(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 tournament_id INTEGER NOT NULL,
 name TEXT NOT NULL,
 club TEXT DEFAULT '',
 seed INTEGER,
 FOREIGN KEY(tournament_id) REFERENCES tournaments(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS matches(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 tournament_id INTEGER NOT NULL,
 round INTEGER NOT NULL,
 match_no INTEGER NOT NULL,
 court TEXT DEFAULT '',
 player1 TEXT,
 player2 TEXT,
 p1_id INTEGER,
 p2_id INTEGER,
 set1_p1 INTEGER,
 set1_p2 INTEGER,
 set2_p1 INTEGER,
 set2_p2 INTEGER,
 set3_p1 INTEGER,
 set3_p2 INTEGER,
 current_p1 INTEGER NOT NULL DEFAULT 0,
 current_p2 INTEGER NOT NULL DEFAULT 0,
 winner TEXT,
 status TEXT NOT NULL DEFAULT 'Menunggu',
 started_at TEXT,
 finished_at TEXT,
 updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 UNIQUE(tournament_id,round,match_no),
 FOREIGN KEY(tournament_id) REFERENCES tournaments(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS score_history(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 match_id INTEGER NOT NULL,
 payload TEXT NOT NULL,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(match_id) REFERENCES matches(id) ON DELETE CASCADE
);
`);

function ensureAdmin(){
 const username=process.env.ADMIN_USERNAME||"admin";
 const password=process.env.ADMIN_PASSWORD||"admin123";
 if(!db.prepare("SELECT id FROM users WHERE username=?").get(username)){
  db.prepare("INSERT INTO users(username,password_hash,role) VALUES(?,?,?)")
    .run(username,bcrypt.hashSync(password,10),"admin");
  console.log(`Admin: ${username} / ${password}`);
 }
}
ensureAdmin();

app.use(express.json({limit:"1mb"}));
app.use(express.static(path.join(__dirname,"public")));

function auth(roles=[]){
 return (req,res,next)=>{
  const token=(req.headers.authorization||"").replace("Bearer ","");
  try{
   const user=jwt.verify(token,SECRET);
   if(roles.length && !roles.includes(user.role)) return res.status(403).json({error:"Akses tidak dibenarkan."});
   req.user=user; next();
  }catch{res.status(401).json({error:"Sesi tidak sah atau telah tamat."});}
 };
}
function getTournament(id){
 const t=db.prepare("SELECT * FROM tournaments WHERE id=?").get(id);
 if(!t)return null;
 return {
  ...t,
  players:db.prepare("SELECT * FROM players WHERE tournament_id=? ORDER BY CASE WHEN seed IS NULL THEN 999999 ELSE seed END,name").all(id),
  matches:db.prepare("SELECT * FROM matches WHERE tournament_id=? ORDER BY round,match_no").all(id)
 };
}
function emitTournament(id){
 io.emit("tournament:changed",{id});
}
function power2(n){let x=1;while(x<n)x*=2;return x;}
function propagate(id,round,no,winner){
 const next=db.prepare("SELECT * FROM matches WHERE tournament_id=? AND round=? AND match_no=?").get(id,round+1,Math.ceil(no/2));
 if(!next)return;
 const field=no%2===1?"player1":"player2";
 db.prepare(`UPDATE matches SET ${field}=? WHERE id=?`).run(winner,next.id);
 const u=db.prepare("SELECT * FROM matches WHERE id=?").get(next.id);
 if(u.player1&&u.player2 && u.status==="Menunggu") return;
}
function generate(id){
 const t=db.prepare("SELECT * FROM tournaments WHERE id=?").get(id);
 const ps=db.prepare("SELECT * FROM players WHERE tournament_id=? ORDER BY CASE WHEN seed IS NULL THEN 999999 ELSE seed END,id").all(id);
 if(!t)throw Error("Kejohanan tidak ditemui.");
 if(ps.length<2)throw Error("Minimum 2 pemain diperlukan.");
 db.prepare("DELETE FROM matches WHERE tournament_id=?").run(id);
 const size=power2(ps.length), rounds=Math.log2(size);
 const slots=ps.map(p=>p.name); while(slots.length<size)slots.push(null);
 for(let r=1;r<=rounds;r++){
  const count=size/2**r;
  for(let n=1;n<=count;n++){
   let p1=null,p2=null;
   if(r===1){p1=slots[(n-1)*2];p2=slots[(n-1)*2+1];}
   db.prepare(`INSERT INTO matches(tournament_id,round,match_no,player1,player2,status)
    VALUES(?,?,?,?,?,?)`).run(id,r,n,p1||null,p2||null,p1&&p2?"Menunggu":(p1||p2?"BYE":"Menunggu"));
  }
 }
 const first=db.prepare("SELECT * FROM matches WHERE tournament_id=? AND round=1 ORDER BY match_no").all(id);
 for(const m of first){
  if((m.player1&&!m.player2)||(!m.player1&&m.player2)){
   const w=m.player1||m.player2;
   db.prepare("UPDATE matches SET winner=?,status='BYE',finished_at=CURRENT_TIMESTAMP WHERE id=?").run(w,m.id);
   propagate(id,1,m.match_no,w);
  }
 }
 db.prepare("UPDATE tournaments SET status='Aktif' WHERE id=?").run(id);
 emitTournament(id); return getTournament(id);
}

app.post("/api/login",(req,res)=>{
 const {username,password}=req.body||{};
 const u=db.prepare("SELECT * FROM users WHERE username=?").get(username||"");
 if(!u||!bcrypt.compareSync(password||"",u.password_hash))return res.status(401).json({error:"Nama pengguna atau kata laluan salah."});
 const token=jwt.sign({id:u.id,username:u.username,role:u.role},SECRET,{expiresIn:"12h"});
 res.json({token,user:{username:u.username,role:u.role}});
});
app.get("/api/me",auth(),(req,res)=>res.json({user:req.user}));
app.get("/api/tournaments",(req,res)=>res.json(db.prepare("SELECT * FROM tournaments ORDER BY id DESC").all()));
app.get("/api/tournaments/:id",(req,res)=>{
 const t=getTournament(Number(req.params.id)); if(!t)return res.status(404).json({error:"Kejohanan tidak ditemui."}); res.json(t);
});

app.post("/api/tournaments",auth(["admin"]),(req,res)=>{
 const b=req.body||{};
 if(!b.name||!b.category)return res.status(400).json({error:"Nama dan kategori diperlukan."});
 const info=db.prepare(`INSERT INTO tournaments(name,date,venue,category,discipline,format,best_of)
 VALUES(?,?,?,?,?,?,?)`).run(b.name,b.date||"",b.venue||"",b.category,b.discipline||"Perseorangan Lelaki",b.format||"knockout",Number(b.best_of)||3);
 res.json(getTournament(info.lastInsertRowid));
});
app.patch("/api/tournaments/:id",auth(["admin"]),(req,res)=>{
 const id=Number(req.params.id), b=req.body||{};
 const t=db.prepare("SELECT * FROM tournaments WHERE id=?").get(id); if(!t)return res.status(404).json({error:"Kejohanan tidak ditemui."});
 db.prepare(`UPDATE tournaments SET name=?,date=?,venue=?,category=?,discipline=?,format=?,best_of=? WHERE id=?`)
 .run(b.name??t.name,b.date??t.date,b.venue??t.venue,b.category??t.category,b.discipline??t.discipline,b.format??t.format,Number(b.best_of||t.best_of),id);
 emitTournament(id);res.json(getTournament(id));
});
app.delete("/api/tournaments/:id",auth(["admin"]),(req,res)=>{
 const id=Number(req.params.id);db.prepare("DELETE FROM tournaments WHERE id=?").run(id);emitTournament(id);res.json({ok:true});
});
app.post("/api/tournaments/:id/players",auth(["admin"]),(req,res)=>{
 const id=Number(req.params.id),b=req.body||{};
 if(!b.name)return res.status(400).json({error:"Nama pemain / pasangan diperlukan."});
 db.prepare("INSERT INTO players(tournament_id,name,club,seed) VALUES(?,?,?,?)").run(id,b.name,b.club||"",b.seed?Number(b.seed):null);
 emitTournament(id);res.json(getTournament(id));
});
app.delete("/api/players/:id",auth(["admin"]),(req,res)=>{
 const p=db.prepare("SELECT tournament_id FROM players WHERE id=?").get(Number(req.params.id));
 if(p){db.prepare("DELETE FROM players WHERE id=?").run(Number(req.params.id));emitTournament(p.tournament_id);}
 res.json({ok:true});
});
app.post("/api/tournaments/:id/generate",auth(["admin"]),(req,res)=>{
 try{res.json(generate(Number(req.params.id)));}catch(e){res.status(400).json({error:e.message});}
});

function setsAndWinner(m,bestOf){
 const vals=[
  [Number(b.set1_p1??m.set1_p1??0),Number(b.set1_p2??m.set1_p2??0)],
  [Number(b.set2_p1??m.set2_p1??0),Number(b.set2_p2??m.set2_p2??0)],
  [Number(b.set3_p1??m.set3_p1??0),Number(b.set3_p2??m.set3_p2??0)]
 ];
 let a=0,c=0;
 for(const [x,y] of vals){if(x>y)a++;else if(y>x)c++;}
 return {vals,a,c,winner:a>c?m.player1:c>a?m.player2:null};
}
app.patch("/api/matches/:id/score",auth(["admin","referee"]),(req,res)=>{
 const id=Number(req.params.id),m=db.prepare("SELECT m.*,t.best_of FROM matches m JOIN tournaments t ON t.id=m.tournament_id WHERE m.id=?").get(id);
 if(!m)return res.status(404).json({error:"Perlawanan tidak ditemui."});
 if(!m.player1||!m.player2)return res.status(400).json({error:"Pemain belum lengkap."});
 const b=req.body||{}, final=b.action==="finish";
 const s=setsAndWinner(m,b,m.best_of);
 if(final&&!s.winner)return res.status(400).json({error:"Pemenang belum boleh ditentukan. Lengkapkan keputusan set dahulu."});
 const status=final?"Selesai":"Sedang Berlangsung";
 const now=new Date().toISOString();
 const payload={
  set1_p1:s.vals[0][0],set1_p2:s.vals[0][1],set2_p1:s.vals[1][0],set2_p2:s.vals[1][1],
  set3_p1:s.vals[2][0],set3_p2:s.vals[2][1],
  current_p1:Number(b.current_p1??m.current_p1),current_p2:Number(b.current_p2??m.current_p2),
  court:b.court??m.court,status,winner:final?s.winner:null,
  started_at:m.started_at||(status==="Sedang Berlangsung"?now:null),
  finished_at:final?now:null,updated_at:now
 };
 const old={...m}; db.prepare(`INSERT INTO score_history(match_id,payload) VALUES(?,?)`).run(id,JSON.stringify(old));
 db.prepare(`UPDATE matches SET set1_p1=?,set1_p2=?,set2_p1=?,set2_p2=?,set3_p1=?,set3_p2=?,
 current_p1=?,current_p2=?,court=?,status=?,winner=?,started_at=?,finished_at=?,updated_at=? WHERE id=?`)
 .run(payload.set1_p1,payload.set1_p2,payload.set2_p1,payload.set2_p2,payload.set3_p1,payload.set3_p2,
 payload.current_p1,payload.current_p2,payload.court,payload.status,payload.winner,payload.started_at,payload.finished_at,payload.updated_at,id);
 if(final)propagate(m.tournament_id,m.round,m.match_no,s.winner);
 emitTournament(m.tournament_id);res.json(getTournament(m.tournament_id));
});
app.post("/api/matches/:id/undo",auth(["admin","referee"]),(req,res)=>{
 const id=Number(req.params.id),last=db.prepare("SELECT * FROM score_history WHERE match_id=? ORDER BY id DESC LIMIT 1").get(id);
 const m=db.prepare("SELECT tournament_id FROM matches WHERE id=?").get(id);
 if(!last||!m)return res.status(400).json({error:"Tiada rekod untuk diundur."});
 const old=JSON.parse(last.payload);
 db.prepare(`UPDATE matches SET player1=?,player2=?,set1_p1=?,set1_p2=?,set2_p1=?,set2_p2=?,set3_p1=?,set3_p2=?,
 current_p1=?,current_p2=?,winner=?,status=?,court=?,started_at=?,finished_at=?,updated_at=? WHERE id=?`)
 .run(old.player1,old.player2,old.set1_p1,old.set1_p2,old.set2_p1,old.set2_p2,old.set3_p1,old.set3_p2,old.current_p1,old.current_p2,old.winner,old.status,old.court,old.started_at,old.finished_at,old.updated_at,id);
 db.prepare("DELETE FROM score_history WHERE id=?").run(last.id);
 emitTournament(m.tournament_id);res.json(getTournament(m.tournament_id));
});
app.get("/api/referees",auth(["admin"]),(req,res)=>res.json(db.prepare("SELECT id,username,role FROM users WHERE role='referee' ORDER BY username").all()));
app.post("/api/referees",auth(["admin"]),(req,res)=>{
 const b=req.body||{};if(!b.username||!b.password)return res.status(400).json({error:"Username dan kata laluan diperlukan."});
 try{db.prepare("INSERT INTO users(username,password_hash,role) VALUES(?,?,?)").run(b.username,bcrypt.hashSync(b.password,10),"referee");res.json({ok:true});}
 catch{res.status(400).json({error:"Username sudah digunakan."});}
});
app.delete("/api/referees/:id",auth(["admin"]),(req,res)=>{db.prepare("DELETE FROM users WHERE id=? AND role='referee'").run(Number(req.params.id));res.json({ok:true});});

app.get("*",(req,res)=>res.sendFile(path.join(__dirname,"public","index.html")));
io.on("connection",s=>s.on("joinTournament",id=>s.join(`tournament:${id}`)));
server.listen(PORT,()=>console.log(`Badminton Live Score V2: http://localhost:${PORT}`));
