# Deployment

## 1. Hosting Node.js
Pilih hosting yang menyokong Node.js dan persistent storage.

Install:
`npm install`

Start:
`npm start`

## 2. Environment
Contoh:
`JWT_SECRET` = secret rawak panjang
`ADMIN_USERNAME` = admin
`ADMIN_PASSWORD` = password kuat

## 3. Database
SQLite disimpan di:
`data/badminton.db`

Hosting mesti menggunakan persistent disk/volume. Jika tidak, data boleh hilang selepas restart/redeploy.

## 4. Domain
Selepas deploy, hosting akan beri URL HTTPS. URL itu boleh digunakan oleh Admin dan Pengadil.

## 5. Keselamatan
- Jangan gunakan `admin123` dalam produksi.
- Jangan kongsi JWT_SECRET.
- Gunakan HTTPS.
- Buat backup database.
